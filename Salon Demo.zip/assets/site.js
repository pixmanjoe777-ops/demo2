// Heavenly Nails — shared site chrome (nav, footer, tweaks)

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "palette": "mocha",
  "mode": "light",
  "cta": "pill",
  "font": "cormorant-figtree",
  "heroVariant": "split",
  "promoText": "First visit — complimentary paraffin hand treatment"
}/*EDITMODE-END*/;

const FONT_PAIRS = {
  "cormorant-figtree": {
    display: "Cormorant Garamond",
    body: "Figtree",
    imports: "family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400&family=Figtree:wght@400;500;600"
  },
  "playfair-nunito": {
    display: "Playfair Display",
    body: "Nunito Sans",
    imports: "family=Playfair+Display:ital,wght@0,400;0,500;1,400&family=Nunito+Sans:wght@400;500;600"
  },
  "dm-serif-manrope": {
    display: "DM Serif Display",
    body: "Manrope",
    imports: "family=DM+Serif+Display:ital@0;1&family=Manrope:wght@400;500;600"
  }
};

function loadFont(key) {
  const pair = FONT_PAIRS[key] || FONT_PAIRS["cormorant-figtree"];
  let link = document.getElementById("__fontlink");
  if (!link) {
    link = document.createElement("link");
    link.id = "__fontlink"; link.rel = "stylesheet";
    document.head.appendChild(link);
  }
  link.href = `https://fonts.googleapis.com/css2?${pair.imports}&family=JetBrains+Mono:wght@400;500&display=swap`;
  document.documentElement.style.setProperty("--font-display", `"${pair.display}", Georgia, serif`);
  document.documentElement.style.setProperty("--font-body", `"${pair.body}", "Helvetica Neue", Arial, sans-serif`);
}

function applyTweaks(t) {
  document.body.dataset.palette = t.palette;
  document.body.dataset.mode = t.mode;
  document.body.dataset.cta = t.cta;
  document.body.dataset.heroVariant = t.heroVariant;
  loadFont(t.font);
  const promoEl = document.querySelector("[data-promo-text]");
  if (promoEl) promoEl.innerHTML = `<strong>Offer</strong> &nbsp; ${t.promoText} &nbsp;·&nbsp; Use code <strong>HEAVENLY10</strong> at booking`;
}

let currentTweaks = { ...TWEAK_DEFAULTS };

function saveTweak(patch) {
  currentTweaks = { ...currentTweaks, ...patch };
  applyTweaks(currentTweaks);
  try {
    window.parent.postMessage({ type: "__edit_mode_set_keys", edits: patch }, "*");
  } catch(e) {}
}

function renderTweaksPanel() {
  const panel = document.createElement("div");
  panel.className = "tweaks";
  panel.id = "__tweaks";
  panel.innerHTML = `
    <h5>Tweaks</h5>
    <div class="row">
      <h5>Palette</h5>
      <div class="chips" data-group="palette">
        ${["mocha","blush","sage","nude"].map(p => `<div class="chip" data-val="${p}">${p}</div>`).join("")}
      </div>
    </div>
    <div class="row">
      <h5>Mode</h5>
      <div class="chips" data-group="mode">
        ${["light","dark"].map(p => `<div class="chip" data-val="${p}">${p}</div>`).join("")}
      </div>
    </div>
    <div class="row">
      <h5>CTA style</h5>
      <div class="chips" data-group="cta">
        ${["pill","square","outline","underline"].map(p => `<div class="chip" data-val="${p}">${p}</div>`).join("")}
      </div>
    </div>
    <div class="row">
      <h5>Font pairing</h5>
      <div class="chips" data-group="font">
        <div class="chip" data-val="cormorant-figtree">cormorant + figtree</div>
        <div class="chip" data-val="playfair-nunito">playfair + nunito</div>
        <div class="chip" data-val="dm-serif-manrope">dm serif + manrope</div>
      </div>
    </div>
    <div class="row hero-only">
      <h5>Hero variant <span style="font-family:var(--font-body);text-transform:none;letter-spacing:0;color:var(--muted)">(home only)</span></h5>
      <div class="chips" data-group="heroVariant">
        ${["split","centered","editorial"].map(p => `<div class="chip" data-val="${p}">${p}</div>`).join("")}
      </div>
    </div>
    <div class="row">
      <h5>Promo copy</h5>
      <input type="text" data-group="promoText" />
    </div>
  `;
  document.body.appendChild(panel);

  // Sync UI state
  function syncUI() {
    panel.querySelectorAll(".chips").forEach(g => {
      const key = g.dataset.group;
      g.querySelectorAll(".chip").forEach(c => {
        c.classList.toggle("on", c.dataset.val === currentTweaks[key]);
      });
    });
    panel.querySelector('input[data-group="promoText"]').value = currentTweaks.promoText;
  }
  syncUI();

  panel.querySelectorAll(".chip").forEach(c => {
    c.addEventListener("click", () => {
      const key = c.parentElement.dataset.group;
      saveTweak({ [key]: c.dataset.val });
      syncUI();
    });
  });
  panel.querySelector('input[data-group="promoText"]').addEventListener("input", (e) => {
    saveTweak({ promoText: e.target.value });
  });
}

function initTweaks() {
  window.addEventListener("message", (e) => {
    if (!e.data || !e.data.type) return;
    if (e.data.type === "__activate_edit_mode") {
      document.getElementById("__tweaks")?.classList.add("on");
    } else if (e.data.type === "__deactivate_edit_mode") {
      document.getElementById("__tweaks")?.classList.remove("on");
    }
  });
  renderTweaksPanel();
  try { window.parent.postMessage({ type: "__edit_mode_available" }, "*"); } catch(e) {}
}

// Render shared chrome
function renderNav(activePage) {
  const links = [
    ["index.html", "Home", "home"],
    ["services.html", "Services", "services"],
    ["gallery.html", "Gallery", "gallery"],
    ["book.html", "Book", "book"],
    ["contact.html", "Contact", "contact"]
  ];
  return `
    <div class="promo-banner" data-promo-text></div>
    <nav class="nav">
      <div class="nav-inner">
        <a href="index.html" class="brand">
          <span class="brand-mark">H</span>
          <span>Heavenly <em style="font-style:italic;color:var(--accent)">Nails</em></span>
        </a>
        <div class="nav-links">
          ${links.map(([href,label,key]) =>
            `<a href="${href}" class="${activePage===key?'active':''}">${label}</a>`).join("")}
          <a href="book.html" class="btn" style="padding:10px 18px;font-size:13px">Book now →</a>
        </div>
      </div>
    </nav>
  `;
}

function renderFooter() {
  return `
    <footer>
      <div class="wrap">
        <div class="foot-grid">
          <div>
            <div class="brand" style="margin-bottom:16px">
              <span class="brand-mark">H</span>
              <span>Heavenly <em style="font-style:italic;color:var(--accent)">Nails</em></span>
            </div>
            <p style="font-size:14px;max-width:280px">
              A warm, boutique nail studio in Glenview —
              meticulous manicures, restorative pedicures, quiet rooms, kind hands.
            </p>
          </div>
          <div>
            <h4>Visit</h4>
            <ul>
              <li>1625 Waukegan Rd</li>
              <li>Glenview, IL 60025</li>
              <li><a href="contact.html">Directions →</a></li>
            </ul>
          </div>
          <div>
            <h4>Hours</h4>
            <ul>
              <li>Mon–Fri · 9:30a – 7:00p</li>
              <li>Sat · 9:30a – 6:00p</li>
              <li>Sun · by appointment</li>
            </ul>
          </div>
          <div>
            <h4>Contact</h4>
            <ul>
              <li><a href="tel:18474864131">(847) 486-4131</a></li>
              <li><a href="book.html">Book online</a></li>
              <li><a href="#">Instagram</a></li>
            </ul>
          </div>
        </div>
        <div class="legal">
          <span>© 2026 Heavenly Nails & Spa</span>
          <span>Est. Glenview · Illinois</span>
        </div>
      </div>
    </footer>
  `;
}

function bootstrap(activePage) {
  // Apply initial tweaks before render
  const header = document.getElementById("site-header");
  const footer = document.getElementById("site-footer");
  if (header) header.innerHTML = renderNav(activePage);
  if (footer) footer.innerHTML = renderFooter();
  applyTweaks(currentTweaks);
  initTweaks();
}

window.HNS = { bootstrap, TWEAK_DEFAULTS };
